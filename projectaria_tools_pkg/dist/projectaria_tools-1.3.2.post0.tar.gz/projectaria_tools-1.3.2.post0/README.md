# projectaria-tools (vendored build)

This directory packages the exact Project Aria Tools bits that are already present in the current environment under `site-packages/projectaria_tools`.  It keeps the full Python sources, type stubs, pybind-based modules, and the prebuilt `_core_pybinds` extension plus the `.dylibs` the tools expect at runtime.  You can re-build and install the package locally with:

```bash
cd /tmp/projectaria_tools_pkg
python -m pip install --upgrade build
python -m build
pip install dist/projectaria_tools-1.3.2.post0-*.whl
```

The produced wheel is self-contained, so you can `pip install` it directly in other clones of ExoRecon without relying on git submodules.
